"""
sensor_fusion.py - ASTRA Multi-Modal Sensor Fusion
Fuses LiDAR point clouds, radar returns, and optical detections using
Kalman-based track-to-track fusion and CI (Covariance Intersection) method.
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class SensorMeasurement:
    sensor_id:   str
    sensor_type: str   # 'lidar' | 'radar' | 'optical'
    position:    np.ndarray   # [x,y,z] km (ECI or relative)
    velocity:    Optional[np.ndarray]    # [vx,vy,vz] m/s
    covariance:  np.ndarray              # 3×3 or 6×6 noise covariance
    timestamp:   float
    confidence:  float
    rcs:         Optional[float] = None  # radar cross-section m²
    snr_db:      Optional[float] = None  # signal-to-noise ratio


@dataclass
class FusedState:
    position:   np.ndarray   # best estimate [x,y,z] km
    velocity:   np.ndarray   # best estimate [vx,vy,vz] m/s
    covariance: np.ndarray   # 6×6 fused covariance
    confidence: float
    sources:    List[str]
    timestamp:  float


class LiDARSensor:
    """Simulated LiDAR point cloud sensor for nearby debris (<50 km)."""

    def __init__(self, range_km=50, angular_res_deg=0.1, noise_sigma=0.001):
        self.range_km    = range_km
        self.ang_res     = angular_res_deg
        self.noise_sigma = noise_sigma
        self.rng         = np.random.default_rng(123)

    def observe(self, debris_positions: List[np.ndarray],
                satellite_pos: np.ndarray, t: float) -> List[SensorMeasurement]:
        """Generate LiDAR returns for visible debris."""
        measurements = []
        for i, pos in enumerate(debris_positions):
            dr   = pos - satellite_pos
            dist = np.linalg.norm(dr)
            if dist > self.range_km * 1e3:
                continue
            # Add ranging noise
            noise = self.rng.normal(0, self.noise_sigma * dist, 3)
            meas_pos = (pos + noise) / 1e3  # convert to km
            cov = np.eye(3) * (self.noise_sigma * dist / 1e3)**2
            measurements.append(SensorMeasurement(
                sensor_id  = f"LIDAR_{i}",
                sensor_type= "lidar",
                position   = meas_pos,
                velocity   = None,
                covariance = cov,
                timestamp  = t,
                confidence = max(0.5, 1.0 - dist/(self.range_km*1e3)),
            ))
        return measurements


class RadarSensor:
    """Simulated phased-array radar for debris detection up to 500 km."""

    def __init__(self, range_km=500, freq_ghz=9.5,
                 range_res_m=10, doppler_res_ms=0.1, noise_sigma=0.01):
        self.range_km   = range_km
        self.freq_ghz   = freq_ghz
        self.range_res  = range_res_m
        self.dop_res    = doppler_res_ms
        self.noise      = noise_sigma
        self.rng        = np.random.default_rng(456)

    def observe(self, debris_states, satellite_state, t: float
                ) -> List[SensorMeasurement]:
        """Generate radar returns with range + Doppler measurements."""
        measurements = []
        sat_pos = satellite_state["pos_km"]
        sat_pos = np.array(sat_pos) * 1e3

        for obj in debris_states[:50]:  # limit for performance
            pos = np.array(obj["pos_km"]) * 1e3
            vel = np.array(obj["vel_ms"])
            dr  = pos - sat_pos
            dist= np.linalg.norm(dr)
            if dist > self.range_km * 1e3:
                continue
            # RCS-based detection probability
            rcs_m2  = 0.1  # default
            det_prob= min(1.0, 0.5 + rcs_m2 / (dist/1000))
            if self.rng.random() > det_prob:
                continue
            # Range noise
            r_noise = self.rng.normal(0, self.range_res, 3)
            meas_pos = (pos + r_noise) / 1e3
            # Doppler velocity
            r_hat  = dr / (dist + 1e-9)
            radial  = np.dot(vel, r_hat)
            v_noise = self.rng.normal(0, self.dop_res)
            meas_vel= r_hat * (radial + v_noise)

            snr = 10 * np.log10(rcs_m2 / (dist/1e3)**4 + 1e-12) + 60
            cov_pos = np.eye(3) * (self.range_res/1e3)**2
            cov_vel = np.eye(3) * self.dop_res**2
            cov_6d  = np.block([[cov_pos, np.zeros((3,3))],
                                 [np.zeros((3,3)), cov_vel]])
            measurements.append(SensorMeasurement(
                sensor_id  = f"RADAR_{obj['id']}",
                sensor_type= "radar",
                position   = meas_pos,
                velocity   = meas_vel,
                covariance = cov_6d,
                timestamp  = t,
                confidence = min(1.0, (snr+20)/60),
                rcs        = rcs_m2,
                snr_db     = snr,
            ))
        return measurements


class CovarianceIntersection:
    """
    Covariance Intersection algorithm for consistent sensor fusion
    without requiring knowledge of cross-correlations.
    CI guarantees consistency even with correlated sources.
    """

    @staticmethod
    def fuse(states: List[Tuple[np.ndarray, np.ndarray]],
             weights: Optional[List[float]] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        Fuse (x_i, P_i) pairs via Covariance Intersection.
        Returns (x_fused, P_fused).
        """
        n = len(states)
        if n == 0:
            raise ValueError("No states to fuse")
        if n == 1:
            return states[0]

        dim = states[0][0].shape[0]
        if weights is None:
            weights = [1.0/n] * n
        # Normalise weights
        w = np.array(weights)
        w /= w.sum()

        P_inv_fused = sum(wi * np.linalg.inv(Pi)
                          for wi, (_, Pi) in zip(w, states))
        P_fused     = np.linalg.inv(P_inv_fused)
        x_fused     = P_fused @ sum(
            wi * np.linalg.inv(Pi) @ xi
            for wi, (xi, Pi) in zip(w, states))
        return x_fused, P_fused


class SensorFusionEngine:
    """
    Multi-modal sensor fusion engine combining LiDAR, Radar, and Optical data.
    Implements sequential Bayesian update + CI for heterogeneous fusion.
    """

    def __init__(self):
        self.lidar    = LiDARSensor()
        self.radar    = RadarSensor()
        self.ci       = CovarianceIntersection()
        self.fused_states: List[FusedState] = []
        self._frame   = 0

    def fuse(self, lidar_meas: List[SensorMeasurement],
              radar_meas: List[SensorMeasurement],
              t: float) -> List[FusedState]:
        """Fuse measurements from all active sensors."""
        self._frame += 1
        fused = []

        all_meas = lidar_meas + radar_meas
        if not all_meas:
            return fused

        # Group by proximity (naïve track association)
        groups = self._cluster_measurements(all_meas)

        for group in groups:
            if not group:
                continue
            # Sequential Bayesian update (or CI if correlated)
            if len(group) == 1:
                m = group[0]
                pos6 = np.zeros(6)
                pos6[:3] = m.position
                if m.velocity is not None:
                    pos6[3:] = m.velocity
                cov6 = np.eye(6) * 1e-3
                cov6[:3,:3] = m.covariance[:3,:3]
            else:
                states_6d = []
                for m in group:
                    x = np.zeros(6); x[:3] = m.position
                    if m.velocity is not None: x[3:] = m.velocity
                    P = np.eye(6) * 0.1
                    P[:3,:3] = m.covariance[:3,:3] if m.covariance.shape[0]==3 \
                               else m.covariance[:3,:3]
                    states_6d.append((x, P))
                pos6, cov6 = self.ci.fuse(states_6d)

            fused.append(FusedState(
                position  = pos6[:3],
                velocity  = pos6[3:],
                covariance= cov6,
                confidence= float(np.mean([m.confidence for m in group])),
                sources   = [m.sensor_type for m in group],
                timestamp = t,
            ))
        self.fused_states = fused
        return fused

    @staticmethod
    def _cluster_measurements(meas: List[SensorMeasurement],
                               threshold_km=1.0) -> List[List[SensorMeasurement]]:
        """Simple distance-based clustering."""
        groups = []
        used   = [False] * len(meas)
        for i, m in enumerate(meas):
            if used[i]: continue
            group = [m]; used[i] = True
            for j, m2 in enumerate(meas):
                if i == j or used[j]: continue
                if np.linalg.norm(m.position - m2.position) < threshold_km:
                    group.append(m2); used[j] = True
            groups.append(group)
        return groups

    def get_status(self) -> dict:
        return {
            "frame":          self._frame,
            "fused_objects":  len(self.fused_states),
            "sensors_active": ["LiDAR", "Radar"],
        }
