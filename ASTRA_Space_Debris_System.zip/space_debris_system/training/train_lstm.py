"""
train_lstm.py - ASTRA LSTM Trajectory Predictor Training Pipeline
Full supervised training pipeline for the BiLSTM+Attention trajectory predictor
with orbital physics-based synthetic data generation and rigorous evaluation.
"""

import numpy as np
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from pathlib import Path
import logging, time, sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from models.lstm_predictor import DebrisLSTMPredictor, TrajectoryDataset

logging.basicConfig(level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ASTRA.LSTM_Train")


def neg_log_likelihood_loss(mu: torch.Tensor, log_sigma: torch.Tensor,
                             target: torch.Tensor) -> torch.Tensor:
    """Gaussian NLL loss for probabilistic trajectory prediction."""
    sigma2 = log_sigma.exp()
    nll    = 0.5*(log_sigma + (target - mu)**2 / (sigma2+1e-8))
    return nll.mean()


def trajectory_rmse(pred: torch.Tensor, target: torch.Tensor) -> float:
    return float(((pred - target)**2).mean().sqrt())


class LSTMTrainer:
    def __init__(self, config: dict):
        self.config  = config
        self.device  = torch.device(
            "cuda" if torch.cuda.is_available() and config.get("gpu",True)
            else "cpu")
        self.ckpt_dir= Path(config.get("checkpoint_dir","checkpoints"))
        self.ckpt_dir.mkdir(parents=True, exist_ok=True)
        self.best_rmse = float("inf")
        logger.info(f"LSTM Trainer | Device: {self.device}")

    def build(self):
        model = DebrisLSTMPredictor(
            input_dim     = self.config.get("input_dim", 14),
            hidden_dim    = self.config.get("hidden_dim", 256),
            num_layers    = self.config.get("num_layers", 3),
            predict_steps = self.config.get("predict_steps", 30),
            dropout       = self.config.get("dropout", 0.2),
        ).to(self.device)
        logger.info(f"LSTM parameters: {model.num_parameters:,}")
        return model

    def get_loaders(self):
        train_ds = TrajectoryDataset(
            n_samples=self.config.get("train_samples",8000),
            seq_len  =self.config.get("seq_len",30),
            pred_len =self.config.get("pred_len",30))
        val_ds   = TrajectoryDataset(
            n_samples=self.config.get("val_samples",2000),
            seq_len  =self.config.get("seq_len",30),
            pred_len =self.config.get("pred_len",30))
        return (DataLoader(train_ds, batch_size=self.config.get("batch_size",32),
                           shuffle=True, num_workers=2),
                DataLoader(val_ds,   batch_size=64, num_workers=2))

    def train(self):
        model = self.build()
        train_dl, val_dl = self.get_loaders()
        epochs = self.config.get("epochs", 200)
        lr     = self.config.get("lr", 1e-4)
        optim_ = optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-5)
        sched  = optim.lr_scheduler.CosineAnnealingLR(optim_, epochs, eta_min=1e-6)

        for epoch in range(1, epochs+1):
            model.train()
            train_losses = []
            for X, Y in train_dl:
                X, Y = X.to(self.device), Y.to(self.device)
                optim_.zero_grad()
                mu, log_sigma, _ = model(X, teacher_forcing=Y)
                loss = neg_log_likelihood_loss(mu, log_sigma, Y)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optim_.step()
                train_losses.append(loss.item())
            sched.step()

            if epoch % 10 == 0:
                model.eval()
                val_rmses = []
                with torch.no_grad():
                    for X, Y in val_dl:
                        X, Y = X.to(self.device), Y.to(self.device)
                        mu, _, _ = model(X)
                        val_rmses.append(trajectory_rmse(mu, Y))
                rmse = np.mean(val_rmses)
                logger.info(f"Epoch {epoch:3d}/{epochs} | "
                            f"Loss={np.mean(train_losses):.4f} | "
                            f"Val RMSE={rmse:.4f} | "
                            f"LR={sched.get_last_lr()[0]:.2e}")
                if rmse < self.best_rmse:
                    self.best_rmse = rmse
                    torch.save(model.state_dict(),
                               self.ckpt_dir/"lstm_best.pt")
                    logger.info(f"Best model saved (RMSE={rmse:.4f})")
        logger.info("LSTM training complete.")
        return model


if __name__ == "__main__":
    trainer = LSTMTrainer({
        "epochs":100, "batch_size":32, "lr":1e-4,
        "hidden_dim":256, "num_layers":3, "predict_steps":30,
        "train_samples":8000, "val_samples":2000,
    })
    trainer.train()
