"""
test_suite.py - ASTRA Comprehensive Unit & Integration Test Suite
Covers orbital mechanics, AI models, sensor fusion, collision prediction,
and end-to-end pipeline integration. Follows pytest conventions.
"""

import numpy as np
import pytest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


# ── Orbital Environment Tests ──────────────────────────────────────────────────

class TestOrbitalEnvironment:
    def setup_method(self):
        from simulation.orbital_env import OrbitalEnvironment
        self.env = OrbitalEnvironment({"environment":"LEO","altitude_km":550,
                                        "time_step_s":1.0})
        self.env.initialize(n_debris=20)

    def test_initialization(self):
        assert len(self.env.debris_states) == 20
        assert self.env.satellite_state is not None

    def test_debris_altitudes_in_leo(self):
        for d in self.env.debris_states:
            alt = d.altitude_km
            assert 150 < alt < 2100, f"Debris altitude out of LEO range: {alt}"

    def test_propagation_step(self):
        pos0 = self.env.satellite_state.position.copy()
        self.env.step(10)
        pos1 = self.env.satellite_state.position
        dist = np.linalg.norm(pos1 - pos0)
        assert dist > 0, "Satellite did not move"
        # Should move ~76 km in 10 seconds at LEO speed
        assert 50e3 < dist < 100e3, f"Unexpected propagation step: {dist:.0f}m"

    def test_time_advances(self):
        t0 = self.env.t
        self.env.step(5)
        assert self.env.t == t0 + 5.0

    def test_state_dict_serializable(self):
        snap = self.env.get_snapshot()
        assert "time_s" in snap
        assert "satellite" in snap
        assert "debris" in snap

    def test_orbital_speed_physical(self):
        sat = self.env.satellite_state
        v   = sat.orbital_speed_ms
        # LEO speed ~7.5–7.8 km/s
        assert 6500 < v < 9000, f"Unrealistic orbital speed: {v}"

    def test_energy_conservation(self):
        """Total orbital energy should be approximately conserved."""
        from simulation.orbital_env import EARTH_MU
        def energy(s):
            r = np.linalg.norm(s.position)
            v = np.linalg.norm(s.velocity)
            return v**2/2 - EARTH_MU/r
        E0 = energy(self.env.satellite_state)
        self.env.step(60)
        E1 = energy(self.env.satellite_state)
        rel_err = abs(E1-E0)/abs(E0)
        assert rel_err < 0.01, f"Energy not conserved: {rel_err:.4f}"


class TestDebrisGenerator:
    def test_class_distribution(self):
        from simulation.orbital_env import DebrisGenerator, DebrisClass, OrbitType
        gen = DebrisGenerator()
        states = gen.generate_field(500, OrbitType.LEO)
        classes = [s.debris_class for s in states]
        counts  = {c: classes.count(c) for c in DebrisClass}
        # Small debris should be most common
        assert counts[DebrisClass.SMALL_DEBRIS] > counts[DebrisClass.DEFUNCT_SATELLITE]

    def test_mass_positive(self):
        from simulation.orbital_env import DebrisGenerator, OrbitType
        gen = DebrisGenerator()
        for s in gen.generate_field(50, OrbitType.LEO):
            assert s.mass_kg > 0
            assert s.area_m2 > 0


# ── Coordinate Transform Tests ─────────────────────────────────────────────────

class TestCoordinateTransforms:
    def test_eci_ecef_roundtrip(self):
        from utils.coordinate_transforms import eci_to_ecef, ecef_to_eci, julian_date
        jd  = julian_date(2025,1,1)
        pos = np.array([7e6, 0, 0])
        vel = np.array([0, 7500, 0])
        p_ecef, v_ecef = eci_to_ecef(pos, vel, jd)
        p_back, v_back = ecef_to_eci(p_ecef, v_ecef, jd)
        assert np.allclose(pos, p_back, atol=1e-3), "ECI→ECEF→ECI roundtrip failed"

    def test_keplerian_conversion(self):
        from utils.coordinate_transforms import state_to_keplerian, keplerian_to_state
        pos = np.array([7e6, 0, 0])
        vel = np.array([0, 7546, 0])
        kep = state_to_keplerian(pos, vel)
        assert 100 < kep["alt_km"] < 1000
        assert kep["e"] < 0.1   # near-circular

    def test_rtn_frame(self):
        from utils.coordinate_transforms import eci_to_rtn, rtn_to_eci
        ref_pos = np.array([7e6, 0, 0])
        ref_vel = np.array([0, 7546, 0])
        obj_pos = ref_pos + np.array([1000, 500, 200])
        obj_vel = ref_vel + np.array([0.1, -0.1, 0.05])
        rtn_p, rtn_v = eci_to_rtn(obj_pos, obj_vel, ref_pos, ref_vel)
        back_p, back_v = rtn_to_eci(rtn_p, rtn_v, ref_pos, ref_vel)
        assert np.allclose(obj_pos, back_p, atol=1e-3)


# ── Detection Model Tests ──────────────────────────────────────────────────────

class TestDetector:
    def test_model_forward_pass(self):
        import torch
        from models.detector import DebrisDetector
        model = DebrisDetector(n_classes=4, variant="n")
        x     = torch.randn(2, 3, 320, 320)
        preds = model(x)
        assert isinstance(preds, list)
        assert len(preds) == 3    # P3/P4/P5

    def test_inference_engine(self):
        import torch
        from models.detector import DebrisDetector, DebrisDetectionEngine
        model  = DebrisDetector(n_classes=4, variant="n")
        engine = DebrisDetectionEngine(model, conf_thresh=0.3)
        img    = np.zeros((640, 640, 3), dtype=np.uint8)
        dets   = engine.detect(img)
        assert isinstance(dets, list)
        for d in dets:
            assert 0.0 <= d.confidence <= 1.0
            assert 0 <= d.class_id < 4

    def test_cnn_transformer(self):
        import torch
        from models.detector import CNNTransformerDetector
        model = CNNTransformerDetector(n_classes=4, embed_dim=128, n_heads=4, n_layers=2)
        x     = torch.randn(2, 3, 320, 320)
        out   = model(x)
        assert out.shape == (2, 4+4)  # classes + bbox


# ── Tracker Tests ──────────────────────────────────────────────────────────────

class TestTracker:
    def setup_method(self):
        from models.tracker import DeepSORTTracker
        self.tracker = DeepSORTTracker(max_age=5, min_hits=2)

    def test_track_creation(self):
        dets = [{"bbox":[0.1,0.1,0.3,0.3],"class_id":0,
                  "class_name":"small_debris","confidence":0.9}]
        self.tracker.update(dets)
        self.tracker.update(dets)
        assert self.tracker.active_count >= 1

    def test_empty_detections(self):
        result = self.tracker.update([])
        assert isinstance(result, list)

    def test_track_summary(self):
        summary = self.tracker.get_summary()
        assert "total_tracks" in summary
        assert "confirmed" in summary

    def test_ekf_predict_update(self):
        from models.tracker import ExtendedKalmanFilter
        ekf  = ExtendedKalmanFilter()
        meas = np.array([0.5, 0.5, 1.0, 50.0])
        ekf.initiate(meas)
        ekf.predict()
        ekf.update(meas + np.array([0.01,0.01,0,0]))
        state = ekf.get_state()
        assert len(state) == 4


# ── LSTM Predictor Tests ───────────────────────────────────────────────────────

class TestLSTMPredictor:
    def test_forward_pass(self):
        import torch
        from models.lstm_predictor import DebrisLSTMPredictor
        model = DebrisLSTMPredictor(input_dim=14, hidden_dim=64,
                                     num_layers=2, predict_steps=10)
        x     = torch.randn(4, 30, 14)
        mu, log_sigma, attn = model(x)
        assert mu.shape == (4, 10, 6)
        assert log_sigma.shape == (4, 10, 6)
        assert attn.shape == (4, 30)

    def test_dataset_generation(self):
        from models.lstm_predictor import TrajectoryDataset
        ds = TrajectoryDataset(n_samples=50, seq_len=20, pred_len=10)
        X, Y = ds[0]
        assert X.shape == (20, 14)
        assert Y.shape == (10, 6)


# ── Collision Prediction Tests ─────────────────────────────────────────────────

class TestCollisionPredictor:
    def setup_method(self):
        from utils.collision_predictor import MonteCarloCollisionPredictor
        self.predictor = MonteCarloCollisionPredictor(n_samples=1000)

    def test_zero_miss_high_pc(self):
        P = np.eye(3) * 100**2
        pc = self.predictor.compute_pc(0.0, 10000, P, P, 5.0)
        assert pc > 0

    def test_large_miss_low_pc(self):
        P  = np.eye(3) * 100**2
        pc = self.predictor.compute_pc(50000.0, 10000, P, P, 5.0)
        assert pc < 1e-4

    def test_alert_levels(self):
        assert self.predictor.alert_level(1e-1) == "RED"
        assert self.predictor.alert_level(5e-3) == "ORANGE"
        assert self.predictor.alert_level(5e-4) == "YELLOW"
        assert self.predictor.alert_level(1e-6) == "GREEN"

    def test_conjunction_analysis(self):
        from utils.collision_predictor import CollisionAlertManager
        mgr = CollisionAlertManager()
        cdm = self.predictor.analyze_conjunction(
            primary_pos   = np.array([7e6,0,0]),
            primary_vel   = np.array([0,7500,0]),
            secondary_pos = np.array([7e6+5e3,0,0]),
            secondary_vel = np.array([0,7500,10]),
        )
        assert cdm.miss_distance_m >= 0
        assert 0 <= cdm.collision_probability <= 1
        assert cdm.alert_level in ("GREEN","YELLOW","ORANGE","RED")


# ── Sensor Fusion Tests ────────────────────────────────────────────────────────

class TestSensorFusion:
    def test_ci_fusion(self):
        from sensors.sensor_fusion import CovarianceIntersection
        x1 = np.array([1.0, 2.0, 3.0])
        P1 = np.eye(3) * 0.1
        x2 = np.array([1.1, 2.1, 3.1])
        P2 = np.eye(3) * 0.2
        xf, Pf = CovarianceIntersection.fuse([(x1,P1),(x2,P2)])
        assert np.allclose(xf, xf)   # no NaN
        assert np.all(np.linalg.eigvals(Pf) > 0)  # positive definite

    def test_lidar_sensor(self):
        from sensors.sensor_fusion import LiDARSensor
        lidar = LiDARSensor(range_km=50)
        sat_pos  = np.array([7e6, 0, 0])
        debris_p = [np.array([7e6+10e3, 0, 0])]
        meas = lidar.observe(debris_p, sat_pos, t=0.0)
        assert len(meas) > 0
        assert meas[0].sensor_type == "lidar"


# ── Space Weather Tests ────────────────────────────────────────────────────────

class TestSpaceWeather:
    def test_kp_range(self):
        from simulation.space_weather import SpaceWeatherSimulator
        sim = SpaceWeatherSimulator()
        for _ in range(100):
            state = sim.step(1800)
            assert 0 <= state.kp_index <= 9

    def test_density_altitude_profile(self):
        from simulation.space_weather import NRLMSISE00Model
        model = NRLMSISE00Model()
        rho_200 = model.density(200)
        rho_500 = model.density(500)
        rho_800 = model.density(800)
        assert rho_200 > rho_500 > rho_800  # density decreases with altitude


# ── Integration Test ───────────────────────────────────────────────────────────

class TestEndToEndPipeline:
    def test_full_pipeline_10_steps(self):
        from simulation.orbital_env import OrbitalEnvironment
        from models.detector import DebrisDetector, DebrisDetectionEngine
        from models.tracker import DeepSORTTracker
        import torch

        env     = OrbitalEnvironment({"environment":"LEO","altitude_km":550,"time_step_s":1.0})
        env.initialize(n_debris=10)
        model   = DebrisDetector(n_classes=4, variant="n")
        engine  = DebrisDetectionEngine(model)
        tracker = DeepSORTTracker()

        for _ in range(10):
            env.step()
            img  = np.zeros((320,320,3), dtype=np.uint8)
            dets = engine.detect(img)
            dicts= [{"bbox":d.bbox,"class_id":d.class_id,
                     "class_name":d.class_name,"confidence":d.confidence}
                    for d in dets]
            tracker.update(dicts)

        assert env.t == 10.0
        assert env.satellite_state is not None
        stats = engine.get_stats()
        assert stats["frames_processed"] == 10


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
