"""
orbital_env.py - ASTRA Orbital Environment Simulation Engine
High-fidelity orbital mechanics with J2-J4 perturbations, atmospheric drag,
debris field generation, and real-time conjunction screening.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from enum import Enum
import time
import logging

logger = logging.getLogger(__name__)

# ── Constants ──────────────────────────────────────────────────────────────────
class OrbitType(Enum):
    LEO = "LEO"
    MEO = "MEO"
    GEO = "GEO"

class DebrisClass(Enum):
    SMALL_DEBRIS      = 0
    LARGE_DEBRIS      = 1
    METALLIC_FRAGMENT = 2
    DEFUNCT_SATELLITE = 3

EARTH_MU    = 3.986004418e14   # m³/s²
EARTH_R     = 6.371e6          # m
EARTH_J2    = 1.08263e-3
EARTH_J4    = -1.6196e-6
ATM_H_SCALE = 8500.0           # m


@dataclass
class OrbitalState:
    object_id:    int
    debris_class: DebrisClass
    position:     np.ndarray    # ECI [m]
    velocity:     np.ndarray    # ECI [m/s]
    mass_kg:      float
    area_m2:      float
    rcs_m2:       float
    timestamp:    float
    active:       bool = True

    @property
    def altitude_km(self):
        return (np.linalg.norm(self.position) - EARTH_R) / 1e3

    @property
    def orbital_speed_ms(self):
        return np.linalg.norm(self.velocity)

    def to_dict(self):
        return {
            "id": self.object_id,
            "class": self.debris_class.name,
            "pos_km": (self.position / 1e3).tolist(),
            "vel_ms": self.velocity.tolist(),
            "alt_km": round(self.altitude_km, 3),
            "speed_ms": round(self.orbital_speed_ms, 2),
        }


@dataclass
class CollisionEvent:
    object_a: int
    object_b: int
    tca_seconds: float
    miss_distance_m: float
    relative_velocity_ms: float
    collision_probability: float
    alert_level: str
    timestamp: float = field(default_factory=time.time)


class OrbitalPropagator:
    """RK4 propagator with J2+J4 gravity and exponential drag."""

    def __init__(self, enable_j2=True, enable_drag=True, enable_srp=True):
        self.enable_j2   = enable_j2
        self.enable_drag = enable_drag
        self.enable_srp  = enable_srp

    def _acceleration(self, r, v, bc):
        R  = np.linalg.norm(r)
        R2 = R * R
        a  = -EARTH_MU / (R2 * R) * r

        if self.enable_j2:
            Re_R = EARTH_R / R
            zR   = r[2] / R
            zR2  = zR * zR
            fj2  = 1.5 * EARTH_J2 * EARTH_MU * Re_R**2 / (R2 * R)
            a[0]+= fj2 * r[0] / R * (5*zR2 - 1)
            a[1]+= fj2 * r[1] / R * (5*zR2 - 1)
            a[2]+= fj2 * r[2] / R * (5*zR2 - 3)
            fj4  = (5/8) * EARTH_J4 * EARTH_MU * Re_R**4 / (R2 * R)
            a[0]+= fj4 * r[0] / R * (3 - 42*zR2 + 63*zR2**2)
            a[1]+= fj4 * r[1] / R * (3 - 42*zR2 + 63*zR2**2)
            a[2]+= fj4 * r[2] / R * (15 - 70*zR2 + 63*zR2**2)

        if self.enable_drag:
            alt = R - EARTH_R
            if alt < 1e6:
                rho  = 1.225 * np.exp(-alt / ATM_H_SCALE)
                vmag = np.linalg.norm(v)
                if vmag > 1e-9:
                    a -= 0.5 * rho / bc * vmag * v
        return a

    def step_rk4(self, state: OrbitalState, dt: float) -> OrbitalState:
        bc = max(state.mass_kg / (2.2 * state.area_m2), 1e-3)
        p, v = state.position.copy(), state.velocity.copy()

        def f(r, vel):
            return vel, self._acceleration(r, vel, bc)

        k1r, k1v = f(p, v)
        k2r, k2v = f(p+.5*dt*k1r, v+.5*dt*k1v)
        k3r, k3v = f(p+.5*dt*k2r, v+.5*dt*k2v)
        k4r, k4v = f(p+dt*k3r,    v+dt*k3v)

        new_p = p + dt/6*(k1r+2*k2r+2*k3r+k4r)
        new_v = v + dt/6*(k1v+2*k2v+2*k3v+k4v)
        return OrbitalState(state.object_id, state.debris_class,
                            new_p, new_v, state.mass_kg, state.area_m2,
                            state.rcs_m2, state.timestamp+dt, state.active)


class DebrisGenerator:
    """Generates realistic debris fields using MASTER-2009 distributions."""

    SIZE_PARAMS = {
        DebrisClass.SMALL_DEBRIS:      {"size_range":(0.01,0.10),"weight":0.55},
        DebrisClass.LARGE_DEBRIS:      {"size_range":(0.10,2.00),"weight":0.25},
        DebrisClass.METALLIC_FRAGMENT: {"size_range":(0.01,0.50),"weight":0.15},
        DebrisClass.DEFUNCT_SATELLITE: {"size_range":(1.00,10.0),"weight":0.05},
    }

    def __init__(self, rng=None):
        self.rng = rng or np.random.default_rng(42)

    def circular_orbit_velocity(self, alt_m, inc_deg):
        R      = EARTH_R + alt_m
        v_circ = np.sqrt(EARTH_MU / R)
        RAAN   = self.rng.uniform(0, 2*np.pi)
        omega  = self.rng.uniform(0, 2*np.pi)
        nu     = self.rng.uniform(0, 2*np.pi)
        inc    = np.radians(inc_deg + self.rng.normal(0, 5))

        cO,sO = np.cos(RAAN),np.sin(RAAN)
        ci,si = np.cos(inc), np.sin(inc)
        cw,sw = np.cos(omega),np.sin(omega)
        cn,sn = np.cos(nu),  np.sin(nu)

        Q = np.array([
            [cO*cw-sO*sw*ci, -cO*sw-sO*cw*ci, sO*si],
            [sO*cw+cO*sw*ci, -sO*sw+cO*cw*ci,-cO*si],
            [sw*si,           cw*si,           ci   ],
        ])
        pos = Q @ (R*np.array([cn,sn,0]))
        vel = Q @ (v_circ*np.array([-sn,cn,0]))
        vel += self.rng.normal(0, 10.0, 3)
        return pos, vel

    def generate_field(self, n_objects, orbit_type=OrbitType.LEO):
        alt_ranges = {
            OrbitType.LEO:(200e3,2000e3),
            OrbitType.MEO:(2000e3,35786e3),
            OrbitType.GEO:(35750e3,35820e3),
        }
        alt_min, alt_max = alt_ranges[orbit_type]
        weights = [v["weight"] for v in self.SIZE_PARAMS.values()]
        classes = list(self.SIZE_PARAMS.keys())
        states  = []

        for obj_id in range(n_objects):
            dclass = self.rng.choice(classes, p=weights)
            size   = self.rng.uniform(*self.SIZE_PARAMS[dclass]["size_range"])
            area   = np.pi*(size/2)**2
            mass   = max(0.001, 2700*4/3*np.pi*(size/2)**3)
            alt    = self.rng.uniform(alt_min, alt_max)
            inc    = self.rng.uniform(0, 98)
            pos, vel = self.circular_orbit_velocity(alt, inc)
            states.append(OrbitalState(
                object_id=obj_id, debris_class=dclass,
                position=pos, velocity=vel,
                mass_kg=mass, area_m2=area,
                rcs_m2=area*self.rng.uniform(0.1,1.0),
                timestamp=0.0,
            ))
        return states


class OrbitalEnvironment:
    """Main orbital simulation environment."""

    def __init__(self, config):
        self.config     = config
        self.orbit_type = OrbitType[config.get("environment","LEO")]
        self.dt         = config.get("time_step_s", 1.0)
        self.t          = 0.0
        self.propagator = OrbitalPropagator()
        self.generator  = DebrisGenerator()
        self.debris_states   = []
        self.satellite_state = None
        self.conjunction_history = []
        self._step_count = 0

    def initialize(self, n_debris=500):
        alt_m = self.config.get("altitude_km",550)*1e3
        inc   = self.config.get("inclination_deg",53)
        pos, vel = self.generator.circular_orbit_velocity(alt_m, inc)
        self.satellite_state = OrbitalState(
            9999, DebrisClass.DEFUNCT_SATELLITE, pos, vel,
            1000.0, 10.0, 8.0, 0.0)
        self.debris_states = self.generator.generate_field(n_debris, self.orbit_type)
        logger.info(f"Initialized: {n_debris} debris + satellite")

    def step(self, n_steps=1):
        for _ in range(n_steps):
            self.satellite_state = self.propagator.step_rk4(self.satellite_state, self.dt)
            self.debris_states   = [self.propagator.step_rk4(s, self.dt)
                                    for s in self.debris_states]
            self.t += self.dt
            self._step_count += 1
        conjunctions = self._screen_conjunctions()
        return {"time_s":self.t,"step":self._step_count,
                "debris_count":len(self.debris_states),
                "conjunctions":[c.__dict__ for c in conjunctions]}

    def _screen_conjunctions(self):
        events = []
        if not self.satellite_state: return events
        sat_pos = self.satellite_state.position
        sat_vel = self.satellite_state.velocity
        for obj in self.debris_states:
            dr   = obj.position - sat_pos
            dist = np.linalg.norm(dr)
            if dist > 50000: continue
            dv   = obj.velocity - sat_vel
            rv   = np.linalg.norm(dv)
            tca  = -np.dot(dr,dv)/(rv**2+1e-12)
            miss = np.linalg.norm(dr + tca*dv)
            pc   = self._compute_pc(miss, rv,
                                    self.satellite_state.area_m2+obj.area_m2)
            level= ("RED" if pc>=1e-2 else "ORANGE" if pc>=1e-3
                    else "YELLOW" if pc>=1e-4 else "GREEN")
            ev = CollisionEvent(9999, obj.object_id, max(0,tca),
                                miss, rv, pc, level, self.t)
            events.append(ev)
            self.conjunction_history.append(ev)
        return events

    @staticmethod
    def _compute_pc(miss_m, rel_vel, combined_area):
        sigma = 100.0
        return combined_area/(2*np.pi*sigma**2)*np.exp(-miss_m**2/(2*sigma**2))

    def get_snapshot(self):
        return {
            "time_s":    self.t,
            "satellite": self.satellite_state.to_dict() if self.satellite_state else None,
            "debris":    [s.to_dict() for s in self.debris_states[:100]],
        }
