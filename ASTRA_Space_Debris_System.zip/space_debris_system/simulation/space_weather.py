"""
space_weather.py - ASTRA Space Weather Simulation Module
Models solar activity, geomagnetic storms, atmospheric density variations,
and solar radiation pressure effects on orbital debris trajectories.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Tuple, Optional
import logging

logger = logging.getLogger(__name__)


@dataclass
class SpaceWeatherState:
    """Current space weather conditions."""
    kp_index:       float   # 0–9  geomagnetic activity index
    f107_flux:      float   # Solar radio flux (sfu), proxy for EUV
    f107_81day_avg: float   # 81-day averaged F10.7
    ap_index:       float   # Geomagnetic ap index (0–400 nT)
    dst_index:      float   # Dst storm index (nT) – negative = storm
    solar_wind_v:   float   # Solar wind speed km/s
    solar_wind_b:   float   # Interplanetary B-field (nT)
    storm_active:   bool    # Geomagnetic storm flag
    radiation_belt_enhanced: bool = False
    timestamp:      float   = 0.0

    @property
    def activity_level(self) -> str:
        if self.kp_index < 2:   return "QUIET"
        if self.kp_index < 4:   return "UNSETTLED"
        if self.kp_index < 6:   return "ACTIVE"
        if self.kp_index < 8:   return "STORM"
        return "SEVERE_STORM"

    def to_dict(self) -> dict:
        return {
            "kp_index":    round(self.kp_index, 2),
            "f107_flux":   round(self.f107_flux, 1),
            "ap_index":    round(self.ap_index, 1),
            "dst_index":   round(self.dst_index, 1),
            "solar_wind":  round(self.solar_wind_v, 0),
            "activity":    self.activity_level,
            "storm":       self.storm_active,
        }


class NRLMSISE00Model:
    """
    Simplified NRLMSISE-00 atmospheric density model.
    Full model requires FORTRAN wrapper; this implements the analytical
    exponential approximation with F10.7/Kp corrections.

    Reference: Picone et al. (2002), J. Geophys. Res.
    """

    # Altitude bands [km] and (rho0 kg/m³, H scale height m, exponent)
    LAYERS = [
        (  0,   86,  1.225,     8500),
        ( 86,  200,  5.4e-7,   17000),
        (200,  300,  1.6e-10,  29500),
        (300,  500,  2.1e-11,  38000),
        (500,  700,  5.0e-12,  50000),
        (700, 1000,  7.0e-13,  65000),
        (1000,2000,  3.0e-14,  90000),
    ]

    def density(self, alt_km: float, f107: float = 150.0,
                kp: float = 3.0) -> float:
        """
        Returns atmospheric density [kg/m³] at given altitude.
        Applies F10.7 and Kp corrections per NRLMSISE-00 empirical fits.
        """
        # Select altitude layer
        rho0, H = 3e-15, 100_000
        for lo, hi, r0, h in self.LAYERS:
            if lo <= alt_km <= hi:
                rho0 = r0; H = h; break

        rho = rho0 * np.exp(-(alt_km*1e3 - lo*1e3) / H)
        # Solar flux correction (Jacchia-77 style)
        f107_corr = 1.0 + 0.004*(f107-150) + 0.006*(f107-150)**2/150
        # Kp correction (geomagnetic heating)
        kp_corr   = np.exp(0.05*kp)
        return rho * f107_corr * kp_corr


class SpaceWeatherSimulator:
    """
    Dynamic space weather simulation with realistic solar cycle,
    geomagnetic storm generation, and radiation belt modelling.
    """

    def __init__(self, seed: int = 42):
        self.rng    = np.random.default_rng(seed)
        self.atm    = NRLMSISE00Model()
        self.t      = 0.0
        self.dt_day = 0.0

        # Solar cycle parameters (11-year cycle)
        self.solar_cycle_phase = self.rng.uniform(0, 2*np.pi)
        self.f107_base = self.rng.uniform(70, 250)   # current solar flux

        # Initialise state
        self.state = self._generate_state(0.0)

    def _generate_state(self, t_s: float) -> SpaceWeatherState:
        """Generate space weather state at time t_s seconds."""
        t_day = t_s / 86400.0
        # Solar cycle F10.7 variation (~11-year period = 4015 days)
        f107 = (self.f107_base +
                30*np.sin(2*np.pi*t_day/4015 + self.solar_cycle_phase) +
                self.rng.normal(0, 5))
        f107 = np.clip(f107, 65, 300)
        f107_avg = f107 * 0.95 + self.rng.normal(0, 2)  # smoothed

        # Geomagnetic Kp with storm probability
        storm = self.rng.random() < 0.03  # 3% chance per step
        if storm:
            kp  = self.rng.uniform(5, 9)
            dst = self.rng.uniform(-200, -50)
        else:
            kp  = abs(self.rng.normal(2.0, 1.5))
            dst = self.rng.normal(-10, 15)
        kp   = np.clip(kp, 0, 9)
        ap   = 2**((kp/3)+1)  # Kp → ap conversion approximation
        v_sw = self.rng.normal(450, 80) if storm else self.rng.normal(350, 50)
        b_sw = self.rng.normal(10, 5)   if storm else self.rng.normal(5, 2)

        return SpaceWeatherState(
            kp_index       = float(kp),
            f107_flux      = float(f107),
            f107_81day_avg = float(f107_avg),
            ap_index       = float(np.clip(ap, 0, 400)),
            dst_index      = float(dst),
            solar_wind_v   = float(max(200, v_sw)),
            solar_wind_b   = float(abs(b_sw)),
            storm_active   = storm,
            radiation_belt_enhanced = kp > 6,
            timestamp      = t_s,
        )

    def step(self, dt_s: float) -> SpaceWeatherState:
        """Advance space weather by dt_s seconds."""
        self.t += dt_s
        # Update every 30 minutes (space weather varies slowly)
        if self.t % 1800 < dt_s:
            self.state = self._generate_state(self.t)
        return self.state

    def atmospheric_density(self, alt_km: float) -> float:
        """Return current atmospheric density at given altitude [kg/m³]."""
        return self.atm.density(alt_km, self.state.f107_flux, self.state.kp_index)

    def drag_scale_factor(self) -> float:
        """
        Multiplicative scale factor for atmospheric drag due to
        geomagnetic storm heating of upper atmosphere.
        """
        base = 1.0
        if self.state.kp_index > 5:
            # Density enhancement during storms (Jacchia 1970)
            base *= np.exp(0.1*(self.state.kp_index - 5))
        base *= (1 + 0.004*(self.state.f107_flux - 150))
        return float(np.clip(base, 0.5, 5.0))

    def solar_radiation_pressure(self, area_m2: float,
                                  mass_kg: float,
                                  cr: float = 1.3) -> np.ndarray:
        """
        Solar radiation pressure acceleration [m/s²] in ECI sun direction.
        cr = reflectivity coefficient (1=absorb, 2=specular)
        """
        P_sr = 4.56e-6   # N/m² at 1 AU
        a_srp = cr * P_sr * area_m2 / max(mass_kg, 1e-3)
        # Sun direction approximation (simplified, ecliptic assumed)
        sun_dir = np.array([1.0, 0.0, 0.0])
        return a_srp * sun_dir
