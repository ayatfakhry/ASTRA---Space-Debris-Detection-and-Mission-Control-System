# 🛰️ ASTRA: AI Space Tracking & Recognition Architecture

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**Research-grade autonomous space debris detection, classification, tracking, and collision prediction system using deep learning and orbital mechanics.**

See docs/ folder for full documentation.
