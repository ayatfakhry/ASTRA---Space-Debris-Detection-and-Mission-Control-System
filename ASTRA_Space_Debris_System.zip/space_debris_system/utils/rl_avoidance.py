"""
rl_avoidance.py - ASTRA Reinforcement Learning Evasive Manoeuvre Planner
Uses Proximal Policy Optimization (PPO) to learn fuel-optimal debris avoidance
manoeuvres satisfying ΔV budget, collision probability, and orbital constraints.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from typing import Tuple, List, Optional, Dict
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


# ── Gymnasium-Compatible Environment ──────────────────────────────────────────

@dataclass
class AvoidanceState:
    satellite_pos:  np.ndarray   # ECI [m]
    satellite_vel:  np.ndarray   # ECI [m/s]
    debris_pos:     np.ndarray   # ECI [m]
    debris_vel:     np.ndarray   # ECI [m/s]
    tca_s:          float        # time to closest approach [s]
    miss_dist_m:    float        # predicted miss distance [m]
    pc:             float        # collision probability
    fuel_remaining: float        # kg
    manoeuvre_count: int


class DebrisAvoidanceEnv:
    """
    Custom orbital mechanics environment for RL avoidance training.
    Action:   ΔV impulse vector [dvx, dvy, dvz] in RTN frame [m/s]
    State:    relative position, velocity, TCA, Pc, fuel, orbit elements
    Reward:   R = r_safety + r_fuel + r_orbital + r_timing
    """

    MAX_DV_MS   = 2.0      # m/s maximum single manoeuvre
    FUEL_BUDGET = 10.0     # kg total fuel
    ISP         = 220.0    # Isp [s]  (cold gas thruster)
    G0          = 9.80665  # m/s²
    EARTH_MU    = 3.986004418e14
    DT_S        = 10.0     # simulation step [s]
    MAX_STEPS   = 500

    def __init__(self, rng_seed: int = 42):
        self.rng   = np.random.default_rng(rng_seed)
        self.state = None
        self.step_count = 0
        self.obs_dim    = 18   # state observation dimension
        self.act_dim    = 3    # ΔV in RTN [dvR, dvT, dvN]

    def reset(self) -> np.ndarray:
        """Reset to a random conjunction scenario."""
        alt = self.rng.uniform(400e3, 800e3)
        R   = 6.371e6 + alt
        v0  = np.sqrt(self.EARTH_MU/R)
        # Satellite in circular orbit
        sat_pos = np.array([R, 0.0, 0.0])
        sat_vel = np.array([0.0, v0, 0.0])
        # Debris on crossing trajectory
        dR  = self.rng.uniform(10e3, 30e3)
        dv  = self.rng.uniform(5000, 15000)
        dir_vec = self.rng.standard_normal(3)
        dir_vec/= np.linalg.norm(dir_vec)
        deb_pos = sat_pos + dR * dir_vec
        deb_vel = sat_vel + dv * self.rng.standard_normal(3)

        self.state = AvoidanceState(
            satellite_pos   = sat_pos,
            satellite_vel   = sat_vel,
            debris_pos      = deb_pos,
            debris_vel      = deb_vel,
            tca_s           = self.rng.uniform(60, 3600),
            miss_dist_m     = dR,
            pc              = self.rng.uniform(1e-4, 1e-1),
            fuel_remaining  = self.FUEL_BUDGET,
            manoeuvre_count = 0,
        )
        self.step_count = 0
        return self._observe()

    def _observe(self) -> np.ndarray:
        """Construct normalised observation vector."""
        s   = self.state
        dr  = (s.debris_pos - s.satellite_pos) / 50e3    # normalise 50km
        dv  = (s.debris_vel - s.satellite_vel) / 10e3   # normalise 10km/s
        return np.array([
            *dr,                                  # 3
            *dv,                                  # 3
            s.satellite_vel[0]/8000,              # 3
            s.satellite_vel[1]/8000,
            s.satellite_vel[2]/8000,
            s.tca_s/3600,                         # 1
            np.log10(max(s.pc,1e-10))/10 + 1,    # 1
            s.miss_dist_m/50e3,                   # 1
            s.fuel_remaining/self.FUEL_BUDGET,    # 1
            np.linalg.norm(s.satellite_pos)/7e6,  # 1
            s.manoeuvre_count/10,                 # 1
            float(s.tca_s < 300),                 # 1  urgency flag
            float(s.pc > 1e-3),                   # 1  danger flag
        ], dtype=np.float32)

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, dict]:
        """Apply ΔV manoeuvre and advance simulation."""
        s = self.state
        # Clip action to ΔV budget
        dv_mag = np.linalg.norm(action)
        if dv_mag > self.MAX_DV_MS:
            action = action / dv_mag * self.MAX_DV_MS

        # Tsiolkovsky: fuel cost
        dm = s.fuel_remaining * (1 - np.exp(-np.linalg.norm(action) /
                                             (self.ISP*self.G0 + 1e-9)))
        s.fuel_remaining = max(0.0, s.fuel_remaining - dm)
        s.satellite_vel += action
        s.manoeuvre_count += 1

        # Propagate (simple Keplerian + linear debris)
        s.satellite_pos += s.satellite_vel * self.DT_S
        s.debris_pos    += s.debris_vel    * self.DT_S
        s.tca_s = max(0, s.tca_s - self.DT_S)

        # Update miss distance
        dr     = s.debris_pos - s.satellite_pos
        dv_rel = s.debris_vel - s.satellite_vel
        rv     = np.linalg.norm(dv_rel)
        tca    = max(0, -np.dot(dr, dv_rel)/(rv**2+1e-12))
        s.miss_dist_m = np.linalg.norm(dr + tca*dv_rel)
        s.pc          = self._compute_pc(s.miss_dist_m)
        s.tca_s       = tca

        reward = self._compute_reward(action, dm)
        done   = (s.tca_s < self.DT_S or self.step_count >= self.MAX_STEPS
                  or s.fuel_remaining < 0.01)
        self.step_count += 1
        return self._observe(), reward, done, {"miss_m": s.miss_dist_m,
                                               "pc": s.pc, "dv_m/s": np.linalg.norm(action)}

    def _compute_reward(self, action: np.ndarray, fuel_used_kg: float) -> float:
        s = self.state
        # Safety reward: log-scale Pc reduction
        r_safety = -np.log10(max(s.pc, 1e-10)) * 2.0 if s.pc < 1e-4 else -10.0
        # Miss distance reward
        r_miss   = np.log1p(s.miss_dist_m/1000) * 0.5
        # Fuel penalty
        r_fuel   = -fuel_used_kg * 5.0
        # Orbital deviation penalty (keep ΔV small)
        r_dv     = -np.linalg.norm(action) * 2.0
        # Timing: earlier manoeuvre = better
        r_time   = 0.1 * (s.tca_s/3600)
        return float(r_safety + r_miss + r_fuel + r_dv + r_time)

    @staticmethod
    def _compute_pc(miss_m: float) -> float:
        sigma = 100.0
        r_hard = 5.0
        return (r_hard**2/(2*sigma**2)) * np.exp(-miss_m**2/(2*sigma**2))


# ── PPO Agent ─────────────────────────────────────────────────────────────────

class ActorCriticNetwork(nn.Module):
    """Shared-backbone Actor-Critic for PPO manoeuvre planning."""

    def __init__(self, obs_dim: int, act_dim: int, hidden: int = 256):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.LayerNorm(hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.LayerNorm(hidden), nn.Tanh(),
            nn.Linear(hidden, hidden//2), nn.Tanh(),
        )
        self.actor_mu    = nn.Linear(hidden//2, act_dim)
        self.actor_log_std= nn.Parameter(torch.zeros(act_dim))
        self.critic      = nn.Linear(hidden//2, 1)

        nn.init.orthogonal_(self.actor_mu.weight, 0.01)
        nn.init.orthogonal_(self.critic.weight, 1.0)

    def forward(self, x: torch.Tensor) -> Tuple:
        feat  = self.shared(x)
        mu    = self.actor_mu(feat)
        std   = self.actor_log_std.exp().expand_as(mu)
        value = self.critic(feat).squeeze(-1)
        return mu, std, value

    def get_action(self, obs: np.ndarray
                   ) -> Tuple[np.ndarray, float, float]:
        """Sample action from policy, return (action, log_prob, value)."""
        x   = torch.from_numpy(obs.astype(np.float32)).unsqueeze(0)
        mu, std, val = self.forward(x)
        dist = torch.distributions.Normal(mu, std)
        act  = dist.sample()
        lp   = dist.log_prob(act).sum(-1)
        return act.squeeze(0).numpy(), lp.item(), val.item()


class PPOTrainer:
    """
    Proximal Policy Optimization trainer for avoidance manoeuvre planning.
    Implements clipped surrogate objective with GAE advantage estimation.
    """

    def __init__(self, obs_dim: int, act_dim: int, lr: float = 3e-4,
                 clip_eps: float = 0.2, gamma: float = 0.99,
                 lam: float = 0.95, device: str = "cpu"):
        self.device   = device
        self.gamma    = gamma
        self.lam      = lam
        self.clip_eps = clip_eps
        self.net      = ActorCriticNetwork(obs_dim, act_dim).to(device)
        self.optim    = optim.Adam(self.net.parameters(), lr=lr)
        self.env      = DebrisAvoidanceEnv()

    def collect_rollout(self, n_steps: int = 2048) -> dict:
        """Collect trajectory experience."""
        obs_l, act_l, rew_l, val_l, lp_l, done_l = [], [], [], [], [], []
        obs = self.env.reset()
        for _ in range(n_steps):
            act, lp, val = self.net.get_action(obs)
            next_obs, rew, done, _ = self.env.step(act)
            obs_l.append(obs); act_l.append(act)
            rew_l.append(rew); val_l.append(val)
            lp_l.append(lp);   done_l.append(float(done))
            obs = self.env.reset() if done else next_obs
        # GAE advantage
        _, _, last_val = self.net.get_action(obs)
        adv, ret = [], []
        gae = 0.0
        for t in reversed(range(n_steps)):
            delta = rew_l[t] + self.gamma*(1-done_l[t])*(
                val_l[t+1] if t<n_steps-1 else last_val) - val_l[t]
            gae   = delta + self.gamma*self.lam*(1-done_l[t])*gae
            adv.insert(0, gae)
            ret.insert(0, gae + val_l[t])
        return {"obs":np.array(obs_l),"act":np.array(act_l),
                "ret":np.array(ret),"adv":np.array(adv),
                "lp": np.array(lp_l)}

    def update(self, batch: dict, n_epochs: int = 10,
               mini_batch: int = 256) -> dict:
        """PPO policy update with clipped surrogate loss."""
        obs = torch.FloatTensor(batch["obs"]).to(self.device)
        act = torch.FloatTensor(batch["act"]).to(self.device)
        ret = torch.FloatTensor(batch["ret"]).to(self.device)
        adv = torch.FloatTensor(batch["adv"]).to(self.device)
        old_lp = torch.FloatTensor(batch["lp"]).to(self.device)
        adv    = (adv - adv.mean()) / (adv.std()+1e-8)
        pl_log, vl_log = [], []
        N = len(obs)
        for _ in range(n_epochs):
            idx = torch.randperm(N)
            for start in range(0, N, mini_batch):
                mb  = idx[start:start+mini_batch]
                mu, std, val = self.net(obs[mb])
                dist = torch.distributions.Normal(mu, std)
                lp   = dist.log_prob(act[mb]).sum(-1)
                ratio= (lp - old_lp[mb]).exp()
                s1   = ratio * adv[mb]
                s2   = ratio.clamp(1-self.clip_eps, 1+self.clip_eps) * adv[mb]
                p_loss = -torch.min(s1,s2).mean()
                v_loss = F.mse_loss(val, ret[mb])
                e_loss = -dist.entropy().mean() * 0.01
                loss   = p_loss + 0.5*v_loss + e_loss
                self.optim.zero_grad(); loss.backward()
                nn.utils.clip_grad_norm_(self.net.parameters(), 0.5)
                self.optim.step()
                pl_log.append(p_loss.item()); vl_log.append(v_loss.item())
        return {"policy_loss": np.mean(pl_log),
                "value_loss":  np.mean(vl_log)}

    def train(self, n_iterations: int = 200) -> List[dict]:
        logs = []
        for i in range(n_iterations):
            batch  = self.collect_rollout()
            update = self.update(batch)
            avg_r  = np.mean(batch["ret"])
            logs.append({"iter":i+1,"avg_return":avg_r,**update})
            if (i+1) % 20 == 0:
                logger.info(f"PPO Iter {i+1}/{n_iterations} | "
                            f"AvgReturn={avg_r:.2f} | "
                            f"PolicyLoss={update['policy_loss']:.4f}")
        return logs
