"""
collision_predictor.py - ASTRA Collision Prediction & Conjunction Analysis
Monte Carlo Pc estimation, TCA computation, and multi-level alert management
per NASA/ESA Conjunction Data Message (CDM) standards.
"""

import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, field
from scipy.stats import multivariate_normal
import time
import logging

logger = logging.getLogger(__name__)


@dataclass
class ConjunctionData:
    """Conjunction Data Message (CDM) compliant record."""
    primary_id:           int
    secondary_id:         int
    tca_epoch:            float        # seconds from simulation epoch
    miss_distance_m:      float
    relative_speed_ms:    float
    collision_probability: float
    alert_level:          str
    # State at TCA
    primary_pos_km:       np.ndarray = field(default_factory=lambda: np.zeros(3))
    secondary_pos_km:     np.ndarray = field(default_factory=lambda: np.zeros(3))
    relative_vel_ms:      np.ndarray = field(default_factory=lambda: np.zeros(3))
    # Covariance (3×3)
    primary_cov_km2:      np.ndarray = field(default_factory=lambda: np.eye(3)*0.01)
    secondary_cov_km2:    np.ndarray = field(default_factory=lambda: np.eye(3)*0.01)
    created_at:           float = field(default_factory=time.time)

    @property
    def risk_score(self) -> float:
        """Composite risk score [0–1]."""
        pc_score   = min(1.0, np.log10(max(self.collision_probability, 1e-10))/(-10))
        miss_score = max(0.0, 1.0 - self.miss_distance_m/10000)
        vel_score  = min(1.0, self.relative_speed_ms/15000)
        return 0.5*pc_score + 0.3*miss_score + 0.2*vel_score

    def to_dict(self) -> dict:
        return {
            "primary_id":   self.primary_id,
            "secondary_id": self.secondary_id,
            "tca_s":        round(self.tca_epoch, 2),
            "miss_dist_m":  round(self.miss_distance_m, 2),
            "rel_speed_ms": round(self.relative_speed_ms, 2),
            "pc":           f"{self.collision_probability:.3e}",
            "alert":        self.alert_level,
            "risk_score":   round(self.risk_score, 4),
        }


class MonteCarloCollisionPredictor:
    """
    NASA-standard Monte Carlo collision probability calculator.

    Method: Samples correlated position uncertainty ellipsoids for both
    objects and computes fraction of samples within hard-body radius.

    Reference: Foster & Vasile (2001), Alfano (2005)
    """

    # Alert thresholds (Pc)
    THRESHOLDS = {
        "GREEN":  1e-5,
        "YELLOW": 1e-4,
        "ORANGE": 1e-3,
        "RED":    1e-2,
    }

    def __init__(self, n_samples: int = 10_000, seed: int = 42):
        self.n_samples = n_samples
        self.rng       = np.random.default_rng(seed)

    def compute_pc(self, miss_m: float, rel_vel_ms: float,
                   primary_cov:   np.ndarray,
                   secondary_cov: np.ndarray,
                   combined_radius_m: float = 5.0) -> float:
        """
        Full Monte Carlo Pc estimation.
        Returns Pc (probability of collision in [0,1]).
        """
        # Combined covariance in encounter frame
        P_comb = primary_cov + secondary_cov
        if np.linalg.matrix_rank(P_comb) < 3:
            return self._foster_pc(miss_m, P_comb, combined_radius_m)

        # Sample conjunction geometry
        try:
            samples = self.rng.multivariate_normal(
                mean=np.zeros(3), cov=P_comb, size=self.n_samples)
            # Miss vector (along radial in simplified 1D)
            miss_vec = np.array([miss_m, 0.0, 0.0])
            rel_pos  = miss_vec + samples
            distances = np.linalg.norm(rel_pos, axis=1)
            pc = float(np.sum(distances < combined_radius_m) / self.n_samples)
        except np.linalg.LinAlgError:
            pc = self._foster_pc(miss_m, P_comb, combined_radius_m)
        return pc

    @staticmethod
    def _foster_pc(miss_m: float, cov: np.ndarray,
                   r_hard: float = 5.0) -> float:
        """Foster (2001) analytical 2D Pc approximation."""
        sigma = np.sqrt(np.trace(cov) / 3)
        if sigma < 1e-9: return 0.0
        u = miss_m**2 / (2*sigma**2)
        return (r_hard**2 / (2*sigma**2)) * np.exp(-u)

    @staticmethod
    def alert_level(pc: float) -> str:
        if pc >= 1e-2:  return "RED"
        if pc >= 1e-3:  return "ORANGE"
        if pc >= 1e-4:  return "YELLOW"
        return "GREEN"

    def analyze_conjunction(self,
                             primary_pos:    np.ndarray,
                             primary_vel:    np.ndarray,
                             secondary_pos:  np.ndarray,
                             secondary_vel:  np.ndarray,
                             primary_id:     int = 0,
                             secondary_id:   int = 1,
                             primary_cov:    Optional[np.ndarray] = None,
                             secondary_cov:  Optional[np.ndarray] = None,
                             combined_radius_m: float = 5.0
                             ) -> ConjunctionData:
        """
        Full conjunction analysis for two objects.
        Returns CDM-compliant ConjunctionData.
        """
        # Time of Closest Approach (linear approximation)
        dr = secondary_pos - primary_pos
        dv = secondary_vel - primary_vel
        rv = np.linalg.norm(dv)
        tca = max(0.0, -np.dot(dr, dv) / (rv**2 + 1e-12))

        # State at TCA
        pos_p_tca = primary_pos   + primary_vel   * tca
        pos_s_tca = secondary_pos + secondary_vel * tca
        miss      = np.linalg.norm(pos_s_tca - pos_p_tca)

        # Default covariances (100m 1σ position uncertainty)
        P_p = primary_cov   if primary_cov   is not None else np.eye(3)*100**2
        P_s = secondary_cov if secondary_cov is not None else np.eye(3)*100**2

        pc  = self.compute_pc(miss, rv, P_p, P_s, combined_radius_m)
        lvl = self.alert_level(pc)

        return ConjunctionData(
            primary_id            = primary_id,
            secondary_id          = secondary_id,
            tca_epoch             = tca,
            miss_distance_m       = miss,
            relative_speed_ms     = rv,
            collision_probability = pc,
            alert_level           = lvl,
            primary_pos_km        = pos_p_tca / 1e3,
            secondary_pos_km      = pos_s_tca / 1e3,
            relative_vel_ms       = dv,
            primary_cov_km2       = P_p / 1e6,
            secondary_cov_km2     = P_s / 1e6,
        )


class CollisionAlertManager:
    """
    Real-time collision alert management system.
    Maintains active conjunction event registry and escalation logic.
    """

    def __init__(self, pc_threshold: float = 1e-4):
        self.pc_threshold    = pc_threshold
        self.active_alerts:  Dict[Tuple[int,int], ConjunctionData] = {}
        self.alert_history:  List[ConjunctionData] = []
        self.escalations:    List[dict]             = []
        self.predictor       = MonteCarloCollisionPredictor()

    def process_conjunction(self, cdm: ConjunctionData):
        """Register or update a conjunction event."""
        key = (cdm.primary_id, cdm.secondary_id)
        prev = self.active_alerts.get(key)

        if cdm.collision_probability >= self.pc_threshold:
            self.active_alerts[key] = cdm
            self.alert_history.append(cdm)
            if prev and self._escalated(prev, cdm):
                self.escalations.append({
                    "time":  time.time(),
                    "key":   key,
                    "from":  prev.alert_level,
                    "to":    cdm.alert_level,
                })
                logger.warning(
                    f"ALERT ESCALATION: Object {cdm.secondary_id} | "
                    f"{prev.alert_level} → {cdm.alert_level} | "
                    f"Pc={cdm.collision_probability:.2e} | "
                    f"Miss={cdm.miss_distance_m:.1f}m")
        elif key in self.active_alerts:
            del self.active_alerts[key]

    @staticmethod
    def _escalated(prev: ConjunctionData, curr: ConjunctionData) -> bool:
        order = {"GREEN":0,"YELLOW":1,"ORANGE":2,"RED":3}
        return order.get(curr.alert_level,0) > order.get(prev.alert_level,0)

    def get_active_summary(self) -> dict:
        alerts = list(self.active_alerts.values())
        return {
            "total_active":  len(alerts),
            "red_alerts":    sum(1 for a in alerts if a.alert_level=="RED"),
            "orange_alerts": sum(1 for a in alerts if a.alert_level=="ORANGE"),
            "yellow_alerts": sum(1 for a in alerts if a.alert_level=="YELLOW"),
            "highest_risk":  max((a.collision_probability for a in alerts),
                                  default=0.0),
            "alerts":        [a.to_dict() for a in
                               sorted(alerts, key=lambda x:-x.collision_probability)[:10]],
        }
