"""
coordinate_transforms.py - ASTRA Coordinate Reference Frame Transformations
ECI ↔ ECEF ↔ RTN ↔ LVLH frame conversions for orbital mechanics computations.
Implements IAU-76/FK5 reduction (simplified) and perifocal/orbital transforms.
"""

import numpy as np
from typing import Tuple
import logging

logger = logging.getLogger(__name__)

# Earth constants
EARTH_R    = 6.371e6        # m
EARTH_MU   = 3.986004418e14 # m³/s²
EARTH_OMEGA= 7.2921150e-5   # rad/s  (sidereal rotation rate)
J2000_EPOCH= 2451545.0      # Julian date of J2000.0


def julian_date(year: int, month: int, day: int,
                hour: float = 0.0) -> float:
    """Compute Julian Date from calendar date."""
    if month <= 2:
        year -= 1; month += 12
    A = int(year/100)
    B = 2 - A + int(A/4)
    return (int(365.25*(year+4716)) + int(30.6001*(month+1))
            + day + hour/24.0 + B - 1524.5)


def gmst(jd: float) -> float:
    """Greenwich Mean Sidereal Time [radians] from Julian Date."""
    T = (jd - J2000_EPOCH) / 36525.0
    theta = (280.46061837 + 360.98564736629*(jd-J2000_EPOCH)
             + 0.000387933*T**2 - T**3/38710000.0)
    return np.radians(theta % 360.0)


# ── ECI ↔ ECEF ────────────────────────────────────────────────────────────────

def eci_to_ecef(pos_eci: np.ndarray, vel_eci: np.ndarray,
                jd: float) -> Tuple[np.ndarray, np.ndarray]:
    """
    Convert ECI (Earth-Centred Inertial) → ECEF (Earth-Centred Earth-Fixed).
    Applies Greenwich sidereal rotation only (no nutation/precession for speed).
    """
    theta = gmst(jd)
    c, s  = np.cos(theta), np.sin(theta)
    R = np.array([[ c, s, 0],
                  [-s, c, 0],
                  [ 0, 0, 1]])
    # Ω × r correction for velocity
    omega_vec = np.array([0, 0, EARTH_OMEGA])
    pos_ecef  = R @ pos_eci
    vel_ecef  = R @ vel_eci - np.cross(omega_vec, pos_ecef)
    return pos_ecef, vel_ecef


def ecef_to_eci(pos_ecef: np.ndarray, vel_ecef: np.ndarray,
                jd: float) -> Tuple[np.ndarray, np.ndarray]:
    """ECEF → ECI (inverse rotation)."""
    theta = gmst(jd)
    c, s  = np.cos(theta), np.sin(theta)
    R_inv = np.array([[c, -s, 0],
                      [s,  c, 0],
                      [0,  0, 1]])
    omega_vec = np.array([0, 0, EARTH_OMEGA])
    pos_eci   = R_inv @ pos_ecef
    vel_eci   = R_inv @ (vel_ecef + np.cross(omega_vec, pos_ecef))
    return pos_eci, vel_eci


# ── ECEF ↔ Geodetic ───────────────────────────────────────────────────────────

def ecef_to_geodetic(pos_ecef: np.ndarray) -> Tuple[float, float, float]:
    """
    ECEF → Geodetic (lat°, lon°, alt m) using Bowring iterative method.
    WGS-84 ellipsoid parameters.
    """
    a   = 6378137.0          # semi-major axis [m]
    f   = 1/298.257223563    # flattening
    b   = a*(1-f)
    e2  = 1 - (b/a)**2
    x,y,z = pos_ecef
    lon  = np.degrees(np.arctan2(y, x))
    p    = np.sqrt(x**2+y**2)
    lat  = np.arctan2(z, p*(1-e2))
    for _ in range(5):
        N   = a / np.sqrt(1 - e2*np.sin(lat)**2)
        lat = np.arctan2(z + e2*N*np.sin(lat), p)
    N   = a / np.sqrt(1 - e2*np.sin(lat)**2)
    alt = p/np.cos(lat) - N if abs(np.cos(lat)) > 1e-9 else abs(z)/np.sin(lat) - N*(1-e2)
    return np.degrees(lat), lon, alt


def geodetic_to_ecef(lat_deg: float, lon_deg: float,
                      alt_m: float) -> np.ndarray:
    """Geodetic → ECEF (WGS-84)."""
    a  = 6378137.0; f = 1/298.257223563
    e2 = 2*f - f**2
    lat, lon = np.radians(lat_deg), np.radians(lon_deg)
    N  = a / np.sqrt(1 - e2*np.sin(lat)**2)
    return np.array([
        (N+alt_m)*np.cos(lat)*np.cos(lon),
        (N+alt_m)*np.cos(lat)*np.sin(lon),
        (N*(1-e2)+alt_m)*np.sin(lat),
    ])


# ── ECI ↔ RTN (Radial-Transverse-Normal) ─────────────────────────────────────

def eci_to_rtn_matrix(pos_eci: np.ndarray,
                       vel_eci: np.ndarray) -> np.ndarray:
    """
    Compute rotation matrix Q: ECI → RTN (Hill frame).
    RTN: R = radial (outward), T = transverse (velocity dir.), N = normal (h)
    """
    r_hat = pos_eci / (np.linalg.norm(pos_eci) + 1e-12)
    h     = np.cross(pos_eci, vel_eci)
    n_hat = h / (np.linalg.norm(h) + 1e-12)
    t_hat = np.cross(n_hat, r_hat)
    return np.array([r_hat, t_hat, n_hat])   # (3,3) rows = RTN unit vectors


def eci_to_rtn(pos_eci: np.ndarray, vel_eci: np.ndarray,
               ref_pos: np.ndarray, ref_vel: np.ndarray
               ) -> Tuple[np.ndarray, np.ndarray]:
    """Express relative position/velocity in RTN frame of reference orbit."""
    Q    = eci_to_rtn_matrix(ref_pos, ref_vel)
    dpos = pos_eci - ref_pos
    dvel = vel_eci - ref_vel
    return Q @ dpos, Q @ dvel


def rtn_to_eci(rtn_pos: np.ndarray, rtn_vel: np.ndarray,
               ref_pos: np.ndarray, ref_vel: np.ndarray
               ) -> Tuple[np.ndarray, np.ndarray]:
    """RTN relative state → absolute ECI state."""
    Q    = eci_to_rtn_matrix(ref_pos, ref_vel)
    return ref_pos + Q.T @ rtn_pos, ref_vel + Q.T @ rtn_vel


# ── Keplerian Elements ────────────────────────────────────────────────────────

def state_to_keplerian(pos: np.ndarray, vel: np.ndarray,
                        mu: float = EARTH_MU) -> dict:
    """
    Convert ECI state vector → classical Keplerian elements.
    Returns: {a [m], e, i [deg], RAAN [deg], omega [deg], nu [deg]}
    """
    r  = np.linalg.norm(pos)
    v  = np.linalg.norm(vel)
    h  = np.cross(pos, vel)           # angular momentum vector
    hm = np.linalg.norm(h)
    n  = np.array([0,0,1])            # north pole
    e_vec = ((v**2 - mu/r)*pos - np.dot(pos,vel)*vel) / mu   # eccentricity vector
    e  = np.linalg.norm(e_vec)
    E  = v**2/2 - mu/r                # specific energy
    a  = -mu/(2*E) if abs(E)>1e-9 else 1e12
    i  = np.degrees(np.arccos(np.clip(h[2]/hm, -1,1)))
    node = np.cross(n, h)
    nm   = np.linalg.norm(node)
    RAAN = np.degrees(np.arctan2(node[1], node[0])) % 360
    if nm > 1e-9 and e > 1e-9:
        omega = np.degrees(np.arccos(np.clip(np.dot(node/nm, e_vec/e),-1,1)))
        if e_vec[2] < 0: omega = 360 - omega
    else:
        omega = 0.0
    if e > 1e-9:
        nu = np.degrees(np.arccos(np.clip(np.dot(e_vec/e, pos/r),-1,1)))
        if np.dot(pos, vel) < 0: nu = 360 - nu
    else:
        nu = 0.0
    return {"a_m":a, "e":e, "i_deg":i, "RAAN_deg":RAAN,
            "omega_deg":omega, "nu_deg":nu,
            "alt_km":(r-EARTH_R)/1e3, "period_s":2*np.pi*np.sqrt(a**3/mu)}


def keplerian_to_state(a: float, e: float, i_deg: float,
                        RAAN_deg: float, omega_deg: float, nu_deg: float,
                        mu: float = EARTH_MU
                        ) -> Tuple[np.ndarray, np.ndarray]:
    """Classical Keplerian elements → ECI state vector."""
    i, RAAN = np.radians(i_deg), np.radians(RAAN_deg)
    omega, nu= np.radians(omega_deg), np.radians(nu_deg)
    p  = a*(1-e**2)
    r  = p/(1+e*np.cos(nu))
    # Perifocal frame
    pos_pqw = r*np.array([np.cos(nu), np.sin(nu), 0])
    vel_pqw = np.sqrt(mu/p)*np.array([-np.sin(nu), e+np.cos(nu), 0])
    # Rotation PQW → ECI
    cO,sO = np.cos(RAAN), np.sin(RAAN)
    ci,si = np.cos(i),    np.sin(i)
    cw,sw = np.cos(omega),np.sin(omega)
    Q = np.array([
        [cO*cw-sO*sw*ci, -cO*sw-sO*cw*ci, sO*si],
        [sO*cw+cO*sw*ci, -sO*sw+cO*cw*ci,-cO*si],
        [sw*si,           cw*si,           ci   ],
    ])
    return Q@pos_pqw, Q@vel_pqw
