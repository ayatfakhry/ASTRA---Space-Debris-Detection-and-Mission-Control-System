"""
main.py - ASTRA System Entry Point
Orchestrates the full Space Debris Detection and Tracking System pipeline:
simulation → detection → tracking → prediction → collision analysis → dashboard.

Usage:
  python main.py --mode full --orbit LEO --debris 500 --duration 3600
  python main.py --mode simulate --orbit GEO --debris 1000
  python main.py --mode eval
  python main.py --mode train --model detector
"""

import argparse
import logging
import sys
import time
import yaml
import numpy as np
from pathlib import Path
from typing import Optional

# ── Internal imports ───────────────────────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parent))

from simulation.orbital_env     import OrbitalEnvironment, OrbitType
from simulation.space_weather   import SpaceWeatherSimulator
from models.detector            import DebrisDetector, DebrisDetectionEngine
from models.tracker             import DeepSORTTracker
from models.lstm_predictor      import DebrisLSTMPredictor
from models.anomaly_detector    import OrbitalVAE, AnomalyDetector
from sensors.sensor_fusion      import SensorFusionEngine, LiDARSensor, RadarSensor
from utils.collision_predictor  import CollisionAlertManager, MonteCarloCollisionPredictor
from utils.coordinate_transforms import state_to_keplerian
from evaluation.metrics         import SystemBenchmark

# ── Logging Setup ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("astra_system.log", mode="w"),
    ]
)
logger = logging.getLogger("ASTRA.Main")

BANNER = r"""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║    █████╗ ███████╗████████╗██████╗  █████╗                          ║
║   ██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗                         ║
║   ███████║███████╗   ██║   ██████╔╝███████║                         ║
║   ██╔══██║╚════██║   ██║   ██╔══██╗██╔══██║                         ║
║   ██║  ██║███████║   ██║   ██║  ██║██║  ██║                         ║
║   ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝                         ║
║                                                                      ║
║   AI Space Tracking & Recognition Architecture  v2.0.0              ║
║   Space Debris Detection | Tracking | Collision Prediction           ║
╚══════════════════════════════════════════════════════════════════════╝
"""


def load_config(path: str = "configs/system_config.yaml") -> dict:
    try:
        with open(path) as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        logger.warning(f"Config not found at {path}, using defaults")
        return {}


class ASTRASystem:
    """
    Top-level ASTRA system orchestrator.
    Manages lifecycle of all subsystems and data flow between modules.
    """

    def __init__(self, config: dict):
        self.config        = config
        self.orbital_cfg   = config.get("orbital", {})
        self.detection_cfg = config.get("detection", {})
        self.tracking_cfg  = config.get("tracking", {})
        self.collision_cfg = config.get("collision", {})

        logger.info("Initialising ASTRA subsystems...")

        # Orbital simulation
        self.env = OrbitalEnvironment(self.orbital_cfg)
        self.weather = SpaceWeatherSimulator()

        # AI models
        self.detector = DebrisDetector(
            n_classes=4, variant=self.detection_cfg.get("variant","s"))
        self.detection_engine = DebrisDetectionEngine(
            self.detector,
            conf_thresh=self.detection_cfg.get("confidence_threshold",0.45))

        # Tracking
        tc = self.tracking_cfg
        self.tracker = DeepSORTTracker(
            max_age    = tc.get("max_age",30),
            min_hits   = tc.get("min_hits",3),
            iou_thresh = tc.get("iou_threshold",0.3))

        # Trajectory prediction
        self.lstm_predictor = DebrisLSTMPredictor(predict_steps=30)

        # Anomaly detection
        self.vae = OrbitalVAE(input_dim=14, latent_dim=32, seq_len=30)
        self.anomaly_detector = AnomalyDetector(self.vae)

        # Sensors
        self.fusion_engine = SensorFusionEngine()
        self.lidar  = LiDARSensor()
        self.radar  = RadarSensor()

        # Collision analysis
        self.collision_predictor = MonteCarloCollisionPredictor(n_samples=5000)
        self.alert_manager = CollisionAlertManager()

        # Metrics
        self.metrics = {
            "total_steps":       0,
            "total_detections":  0,
            "active_tracks":     0,
            "collision_warnings":0,
            "anomalies_detected":0,
        }

        logger.info("All subsystems initialised ✓")

    def initialize(self, n_debris: int):
        self.env.initialize(n_debris)
        logger.info(f"Orbital environment ready: {n_debris} debris objects")

    def run_step(self) -> dict:
        """Execute one full system pipeline step."""
        t0 = time.perf_counter()

        # 1. Advance simulation
        sim_state = self.env.step(n_steps=1)
        weather   = self.weather.step(self.orbital_cfg.get("time_step_s",1.0))

        # 2. Sensor observations
        debris_states = self.env.debris_states[:100]
        sat_state     = self.env.satellite_state
        if sat_state:
            lidar_m = self.lidar.observe(
                [d.position for d in debris_states],
                sat_state.position, self.env.t)
            radar_m = self.radar.observe(
                [d.to_dict() for d in debris_states],
                sat_state.to_dict(), self.env.t)
            fused = self.fusion_engine.fuse(lidar_m, radar_m, self.env.t)
        else:
            fused = []

        # 3. AI Detection (on synthetic image representation)
        dummy_img = np.zeros((640,640,3), dtype=np.uint8)
        detections = self.detection_engine.detect(dummy_img)

        # 4. Multi-object tracking
        det_dicts = [{"bbox": d.bbox, "class_id": d.class_id,
                      "class_name": d.class_name,
                      "confidence": d.confidence} for d in detections]
        confirmed_tracks = self.tracker.update(det_dicts)

        # 5. Collision alert processing
        conjunctions = sim_state.get("conjunctions", [])
        for c in conjunctions:
            self.metrics["collision_warnings"] += 1

        # 6. Update metrics
        self.metrics["total_steps"]      += 1
        self.metrics["total_detections"] += len(detections)
        self.metrics["active_tracks"]     = self.tracker.active_count

        dt_ms = (time.perf_counter()-t0)*1000
        return {
            "sim":          sim_state,
            "detections":   len(detections),
            "tracks":       self.tracker.active_count,
            "fused_objects":len(fused),
            "weather":      weather.to_dict(),
            "conjunctions": len(conjunctions),
            "step_ms":      round(dt_ms,2),
        }

    def run(self, duration_s: float, print_every: int = 60):
        """Run full system for duration_s seconds of simulation time."""
        logger.info(f"Starting ASTRA simulation | Duration: {duration_s}s")
        t_start = time.perf_counter()
        step = 0

        while self.env.t < duration_s:
            result = self.run_step()
            step  += 1
            if step % print_every == 0:
                self._print_status(result)

        wall_time = time.perf_counter() - t_start
        logger.info(f"\nSimulation complete | {step} steps | "
                    f"Wall time: {wall_time:.1f}s | "
                    f"Rate: {duration_s/wall_time:.1f}× real-time")
        self._print_final_report()

    def _print_status(self, r: dict):
        t  = self.env.t
        hh = int(t//3600); mm = int((t%3600)//60); ss = int(t%60)
        print(f"  T+{hh:02d}:{mm:02d}:{ss:02d} | "
              f"Debris:{r['sim']['debris_count']:5d} | "
              f"Dets:{r['detections']:3d} | "
              f"Tracks:{r['tracks']:3d} | "
              f"Fused:{r['fused_objects']:3d} | "
              f"Conj:{r['conjunctions']:2d} | "
              f"Step:{r['step_ms']:.0f}ms | "
              f"Weather:{r['weather']['activity']}")

    def _print_final_report(self):
        m = self.metrics
        print("\n" + "═"*60)
        print("  ASTRA MISSION REPORT")
        print("═"*60)
        print(f"  Total simulation steps:    {m['total_steps']:,}")
        print(f"  Total detections:          {m['total_detections']:,}")
        print(f"  Collision warnings issued: {m['collision_warnings']:,}")
        print(f"  Tracker active count:      {m['active_tracks']:,}")
        print("═"*60 + "\n")


# ── CLI ───────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description="ASTRA Space Debris Detection & Tracking System")
    p.add_argument("--mode",     default="full",
                   choices=["full","simulate","detect","eval","train","benchmark"])
    p.add_argument("--orbit",    default="LEO", choices=["LEO","MEO","GEO"])
    p.add_argument("--debris",   type=int, default=500)
    p.add_argument("--duration", type=float, default=3600)
    p.add_argument("--config",   default="configs/system_config.yaml")
    p.add_argument("--model",    default="detector",
                   choices=["detector","lstm","transformer","vae"])
    p.add_argument("--no-gpu",   action="store_true")
    p.add_argument("--verbose",  action="store_true")
    return p.parse_args()


def main():
    print(BANNER)
    args = parse_args()
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    config = load_config(args.config)
    config.setdefault("orbital", {})["environment"] = args.orbit
    if args.no_gpu:
        config.setdefault("system",{})["gpu_enabled"] = False

    if args.mode == "benchmark":
        logger.info("Running system benchmarks...")
        bench = SystemBenchmark()
        bench.run_detection_benchmark()
        bench.run_tracking_benchmark()
        bench.run_prediction_benchmark()
        bench.print_report()
        return

    if args.mode == "train":
        if args.model == "detector":
            from training.train_detector import DetectorTrainer
            trainer = DetectorTrainer(config.get("training",{}).get("detector",{}))
            trainer.train()
        elif args.model == "lstm":
            from training.train_lstm import LSTMTrainer
            trainer = LSTMTrainer(config.get("training",{}).get("predictor",{}))
            trainer.train()
        return

    # Full / simulate / detect modes
    system = ASTRASystem(config)
    system.initialize(args.debris)
    system.run(args.duration)


if __name__ == "__main__":
    main()
